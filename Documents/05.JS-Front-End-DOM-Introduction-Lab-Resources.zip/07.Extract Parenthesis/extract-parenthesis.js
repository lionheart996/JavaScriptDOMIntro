function extract(content) {
    // TODO
}