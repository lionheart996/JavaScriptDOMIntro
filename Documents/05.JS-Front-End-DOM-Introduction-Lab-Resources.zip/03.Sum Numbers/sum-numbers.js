function calc() {
    // TODO
}