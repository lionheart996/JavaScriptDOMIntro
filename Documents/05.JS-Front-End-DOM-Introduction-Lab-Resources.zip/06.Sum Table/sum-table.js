function sumTable() {
    // TODO
}