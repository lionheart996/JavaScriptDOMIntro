function colorize() {
    //TODO
}